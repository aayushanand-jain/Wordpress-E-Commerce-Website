<?php
/**
 * Header Options for  Top Store Theme.
 *
 * @package      Top Store
 * @author       Top Store
 * @since        Top Store 1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'top-store-abv-header-clr';
$wp_customize->get_control( 'header_image' )->priority = 1;
